﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolLibrary
{
    class Teacher : Person
    {
        public string Subject { get; set; }
    }
}
