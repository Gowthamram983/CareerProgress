﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to C# Essential Training Part 1!");
            Console.WriteLine("Press the enter key to exit.");
            Console.ReadLine();
        }
    }
}
