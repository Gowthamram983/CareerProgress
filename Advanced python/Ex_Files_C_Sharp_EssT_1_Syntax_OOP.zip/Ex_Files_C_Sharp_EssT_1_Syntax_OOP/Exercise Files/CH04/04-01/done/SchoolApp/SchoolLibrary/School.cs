﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolLibrary
{
    class School
    {
        string SchoolName;
        string SchoolAddress;
        string SchoolCity;
        string SchooleState;
        string SchoolZip;
        string PhoneNumber;

    }
}
