﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolLibrary.Elementary
{
    class Volume
    {
    }
}
