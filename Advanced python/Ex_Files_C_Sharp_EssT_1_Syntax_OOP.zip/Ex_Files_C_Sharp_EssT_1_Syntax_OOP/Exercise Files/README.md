# CSharpEssentialTrainingPart1

Exercise files for LinkedIn Course C# Essential Training Part 1

Bruce Van Horn II

https://www.linkedin.com/in/brucevanhorn2/

These are the exercise files for the course C# Essential Training Part 1 available on LinkedIn Learning recorded and published in 2017.
