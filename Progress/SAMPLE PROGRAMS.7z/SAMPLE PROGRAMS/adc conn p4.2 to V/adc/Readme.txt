-------- PROJECT GENERATOR --------
PROJECT NAME :	adc
PROJECT DIRECTORY :	C:\WorkSpace\adc\adc
CPU SERIES :	R8C/Tiny
CPU GROUP :	27
TOOLCHAIN NAME :	Renesas M16C Standard Toolchain
TOOLCHAIN VERSION :	5.45.00
GENERATION FILES :
    C:\WorkSpace\adc\adc\adc.c
        main program file.
    C:\WorkSpace\adc\adc\nc_define.inc
        interrupt program.
START UP FILES :
    C:\WorkSpace\adc\adc\sfr_r827.h
    C:\WorkSpace\adc\adc\sfr_r827.inc
    C:\WorkSpace\adc\adc\ncrt0.a30
    C:\WorkSpace\adc\adc\sect30.inc

DATE & TIME : 07.07.2011 22:00:28
