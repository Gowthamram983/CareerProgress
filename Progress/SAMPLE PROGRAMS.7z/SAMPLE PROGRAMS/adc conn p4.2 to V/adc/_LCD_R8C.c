//*************************************************************************************************//
//*************************************************************************************************//
//-------------------------------------------- 16X2 LCD -------------------------------------------//
//*************************************************************************************************//
//*************************************************************************************************//


//-------------------------------------------------------------------------------------------------//
//-------------------------------- Variables & Functions Declaration ------------------------------//
//-------------------------------------------------------------------------------------------------//

#define lcd_port p0     							// Dataport of LCD-Display (D4..D7) 
#define	rs	p0_2
#define	en	p0_3

void lcd_delay();
void lcd_init(void);                        		// Initialize the LCD display
void lcd_cginit(void);                        		// Initialize the Custom Graphics in LCD display
void lcd_clear(void);								// Clear LCD
void lcd_command(char cmd);		    				// Send LCD Command
void lcd_gotoxy(char x,char y);						// Goto X,Y position in the LCD display
void lcd_putchar(char value);  						// Writes a character to display
void lcd_printxy(char x,char y,char *text);
int num_to_char(int val);
void lcd_hex_byte(int val);
//void lcd_print_b(char val_a);
//void lcd_print_b(int );
//void DisplayLCD2Digit(char LineNumber,char CharPosition,char Data);
//void printnum_lcd(unsigned char num, unsigned char row, unsigned char col);
//-------------------------------------------------------------------------------------------------//
//----------------------------------------- Delay Routine -----------------------------------------//
//-------------------------------------------------------------------------------------------------//

void lcd_delay()
{
	unsigned char a;
	a=255;
	while(a--);
	a=255;
	while(a--);
}

//-------------------------------------------------------------------------------------------------//
//-------------------------------------- LCD Initialisation ---------------------------------------//
//-------------------------------------------------------------------------------------------------//

void lcd_init(void)
{
    rs=0;
	en=1;
	lcd_port=0x20;
	en=0;
	lcd_delay();
	lcd_command(0x28);
	lcd_command(0x06);
	lcd_command(0x0C);								// OC - Cursor Off ~ OE - Cursor ON ~ 0F - Cursor Blink
	lcd_command(0x01);								// Clears the display
	lcd_command(0x80);
}

//-------------------------------------------------------------------------------------------------//
//------------------------------------------- LCD Clear -------------------------------------------//
//-------------------------------------------------------------------------------------------------//

void lcd_clear(void)
{
	lcd_command(0x01);
	lcd_delay();
	lcd_delay();
	lcd_delay();
}

//-------------------------------------------------------------------------------------------------//
//--------------------------------------- LCD Send Command ----------------------------------------//
//-------------------------------------------------------------------------------------------------//

void lcd_command(unsigned char cmd)
{
   	rs=0;							// Switch to command register
	lcd_port = (lcd_port&0x0F)|(cmd&0xF0);			// Set LCD_DATA to high nibble of value
	en = 1;
	en = 0;           								// Write data to display													
	lcd_port = (lcd_port&0x0F)|((cmd<<4)&0xF0);		// Set LCD_DATA to lower nibble of value
	en = 1;
	en = 0;           								// Write data to display
	lcd_delay();                       				// Wait 400�s
}

//-------------------------------------------------------------------------------------------------//
//----------------------------------------- LCD Goto X,Y ------------------------------------------//
//-------------------------------------------------------------------------------------------------//

void lcd_gotoxy(unsigned char x,unsigned char y)
{
   	//if((x<1||x>2)) 								// if((x<1||x>2)&&(y<1||y>16))
	if(x>2)
	{
		x=1; 										// x=1; y=1;
	}
	if(x == 1)
		lcd_command(0x7F+y);
	else
		lcd_command(0xBF+y);
}

//-------------------------------------------------------------------------------------------------//
//---------------------------------------- LCD Print Text -----------------------------------------//
//-------------------------------------------------------------------------------------------------//


void lcd_putchar(unsigned char value)
{
	rs = 1;              						    // Switch to data register					 	
	lcd_port = (lcd_port&0x0F)|(value&0xF0);		// Set LCD_DATA to high nibble of value
	en = 1;
	en = 0;           								// Write data to display												
	lcd_port = (lcd_port&0x0F)|((value<<4)&0xF0);	// Set LCD_DATA to lower nibble of value
	en = 1;
	en = 0;           								// Write data to display
	lcd_delay();                       				// Wait 400�s
} 

//-------------------------------------------------------------------------------------------------//

void lcd_printxy(unsigned char x,unsigned char y, unsigned char *text)
{
	lcd_gotoxy(x,y);            						// Set cursor position
	while(*text)          								// while not end of text
	{
	  lcd_putchar(*text); 							    // Write character and increment position
	  text++;
	} 
}

//-------------------------------------------------------------------------------------------------//
//------------------------------- Writing 8-bit Value to LCD --------------------------------------//
//-------------------------------------------------------------------------------------------------//
/*
void lcd_print_b(unsigned char val_a)
{
	unsigned char temp_a;
							   						// 123
	temp_a = val_a/100;				 				// 123 / 100 = 1
	if(temp_a!=0)
	{
		lcd_putchar(temp_a+0x30);
	}
	temp_a = val_a/10;	   							// 123 / 10 = 12
	temp_a = temp_a%10;								// 12 % 10 = 2
	lcd_putchar(temp_a+0x30);
	temp_a = val_a%10;								// 123 % 10 = 3
	lcd_putchar(temp_a+0x30);
}

void DisplayLCD2Digit(char LineNumber,char CharPosition,char Data)
{
   unsigned char a;
   
   if(LineNumber ==1)
   {   //First Line
      a = 0x80;         // Command for first line selection            
   }
   else
   {   //Second line
      a = 0xc0;         // Command for second line selection
   }
   
   
   a+=(CharPosition-1);         // Calculate the character position
   lcd_command(a);         // Send command to select the given digit
   
   
   if( (Data & 0xf0) < 0xa0)      // Check for less than 0xa0
   {
      a = ((Data & 0xf0) >> 4) + '0';   // Get the ASCII character
   }
   else
   {   
      a = ((Data & 0xf0) >> 4) + 'A'- 0x0a;   
                  // Get the ASCII character
   }
   
   
   lcd_command(a);         // Display the first character
   
   if( (Data & 0x0f) < 0x0a)         // Check for less tham 0x0a
   {
      a = (Data & 0x0f)+'0';      // Get the ASCII character
   }
   else
   {
      a = (Data & 0x0f)+'A' - 0x0a;   // Get the ASCII character
   }
   
   lcd_command(a);
   
}*/
void lcd_print_b(unsigned int val_a)
{
	unsigned int temp_a;
							   						// 123
	temp_a = val_a/1000;				 				// 123 / 100 = 1
	if(temp_a!=0)
	{
		lcd_putchar(temp_a+0x30);
	}
	else
		lcd_putchar(0+0x30);
	temp_a = val_a/100;	   							// 123 / 10 = 12
	temp_a = temp_a%10;								// 12 % 10 = 2
	lcd_putchar(temp_a+0x30);
	temp_a = val_a/10;
	temp_a = temp_a%10;	
	lcd_putchar(temp_a+0x30);	
	temp_a = val_a%10;								// 123 % 10 = 3
	lcd_putchar(temp_a+0x30);
	
}
int num_to_char(int val)	// converts val to hex character
{
   int ch;
   if (val < 10)
   {
     ch=val+'0';
   }
   else
   {
     val=val-10;
     ch=val + 'A';
   }
   return(ch);
}
void lcd_hex_byte(int val) // displays val in hex format
{
   int ch;
   ch = num_to_char((val>>8) & 0x000f);
   lcd_putchar(ch);
   ch = num_to_char((val>>4) & 0x0f);
   lcd_putchar(ch);
   ch = num_to_char(val&0x0f);
   lcd_putchar(ch);
}

/*void printnum_lcd(unsigned char num, unsigned char row, unsigned char col)
{
   unsigned char x1, x2,dig3, dig4, dig5;
   unsigned int x3;
	
   x3=num/100;
   x2=num%100;
   x1=x3%100;
   
   
   dig3=x1%10;
   dig4=x2/10;
   dig5=x2%10;

   lcd_command(0x80+(0x40*row)+ col);
   
   lcd_putchar(dig3+0x30);
   lcd_putchar(dig4+0x30);
   lcd_putchar(dig5+0x30);
}*/