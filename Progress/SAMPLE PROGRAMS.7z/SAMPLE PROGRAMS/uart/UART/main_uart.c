/**********************************************************************************
FILE NAME       main.c
DESCRIPTION:    R8C/27 to a terminal program
                via UART1 and RS232.  UART1 configuration is:
                19200 baud, 8-bit data, 1 stop bit, no parity, no flow control.

                Incrementing data (0 to 9) is sent to the terminal window.
                To stop receiving data, press z on the keyboard. To resume, press any key.
                While data is transmitting LED1 is on and LED2 is off.   When transmission
                is stopped by pressing "z" LED2 turns on and LED1 turns off


***************************************************/

#include "rskr8c27def.h"
#include "sfr_r827.h"
#include "main.h"
#include "_LCD_R8C.c"
/* ************************* Global variables ********************************/

unsigned char ucU1_in;

/* String constants used for screen output */
char cmd_clr_scr[] = {27,'[','2','J',0};
char cmd_cur_home[] = {27,'[','H',0};


void main(void) {

   unsigned char ucCount;
   unsigned short ucConvert;
   unsigned short usDelay;

   uart_init();
   lcd_init();
   lcd_clear();
   lcd_delay();
   lcd_printxy(1,2,"UART..");
   lcd_delay();
   lcd_delay();
   lcd_printxy(2,4,"0123456789");
   lcd_delay();
   /* Text to be displayed at the beginning of the program output to the terminal
   window (\r\n = carriage return & linefeed) */

   text_write(cmd_clr_scr);
   text_write(cmd_cur_home);
   text_write("NSK EMBEDDED SOLUTIONS \r\n");
   
   text_write("Press z to stop, any key to continue. \r\n");

/************** MAIN PROGRAM LOOP ***********************/
   for(;;){

   /* setup program loop to count from 0 to 9, stop when "z" is received */

      while (ucU1_in != 'z'){
         /* send carrige return and line feed*/
         text_write("\r\n");
        // LED2 = LED_OFF;
         //LED1 = LED_ON;

         for (ucCount=0;(ucCount<=9)&&(ucU1_in!='z');ucCount ++){
            /* convert count data to ASCII */
            ucConvert = ucCount + 0x30;
            while(ti_u1c1 == 0);
            u1tb = ucConvert;
            for (usDelay=0xffff; usDelay>0; usDelay--);
         }
      }
      /* Do nothing while stopped (after "z" is pressed) */
      _asm("NOP");
   }
}


/*****************************************************************************
Name:    UART1 Receive Interrupt Routine
Parameters:  none
Returns:     none
Description: Interrupt routine for UART1 receive
             Reads character received from keyboard and stores U1_in variable
*****************************************************************************/
void U1rec_ISR(void){

   ucU1_in = (char) u1rb;
   if (ucU1_in == 'z'){
      while(ti_u1c1 == 0);
      u1tb = 'z';
   //   LED2 = LED_ON;
    //  LED1 = LED_OFF;
   }
}

void uart_init(void){

    pinsr1 = 0x05;
   

    pmr = 0x36;
   


   /* set UART1 bit rate generator */
   u1brg = 129;//(unsigned char)(((f1_CLK_SPEED/16)/BAUD_RATE)-1);
      /*
         bit rate can be calculated by:
         bit rate = ((BRG count source / 16)/baud rate) - 1
         ** the value of BCLK does not affect BRG count source
      */

   u1mr = 0x05;
   

   u1c0 = 0x00;
   
   u1tb = u1rb;
   u1tb = 0;
   
   DISABLE_IRQ
   s1ric = 0x04;
   ENABLE_IRQ

   u1c1 = 0x05;
} 


void text_write (char * msg_string)
{
   char i;
   /* This loop reads in the text string and puts it in the UART 0 transmit buffer */
   for (i=0; msg_string[i]; i++){
      while(ti_u1c1 == 0);
      u1tb = msg_string[i];
   }
}

