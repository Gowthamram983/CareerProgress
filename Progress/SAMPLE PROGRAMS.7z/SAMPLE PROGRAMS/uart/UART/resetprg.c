/***********************************************************************************
FILE NAME  	: Resetprg.C
DESCRIPTION : Reset Initialisation Functions for RSKR8C27
              The users program will start in this file.

*/
#include "sfr_r827.h"
#include "hwsetup.h"
#include "main.h"

/**********************************************************************************
Global variables
***********************************************************************************/

/***********************************************************************************
User Program Code
***********************************************************************************/

/**********************************************************************************
Function Name:  Initialise
Description:    Initialise the micon then call main
Parameters:     none
Return value:   none
***********************************************************************************/
void Initialise(void)
{
	/* Initialise all the required peripheral modules */
	HardwareSetup();

	/* main function including users code */
	main();

	/* This function must never exit */
	for(;;);
}
/**********************************************************************************
End of function Initialise
***********************************************************************************/

