

#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

/***********************************************************************************
Function Prototypes
***********************************************************************************/

void main(void);   
void text_write (_far const char * msg_string);
void mcu_init(void);
void uart_init(void);

/**********************************************************************************
Interrupt function declarations
***********************************************************************************/
#pragma INTERRUPT U1rec_ISR
void U1rec_ISR (void);

/***********************************************************************************
Defines for this module
***********************************************************************************/
#define BAUD_RATE	19200


#endif /* MAIN_H_INCLUDED */
