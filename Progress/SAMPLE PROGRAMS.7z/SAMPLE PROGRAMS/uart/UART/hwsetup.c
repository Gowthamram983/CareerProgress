
#include "sfr_r827.h"
/* RSKR8C27def.h provides common defines for widely used items. */
#include "rskR8C27def.h"
#include "hwsetup.h"

/***********************************************************************************
User Program Code Prototypes
***********************************************************************************/
/* These functions are private so their prototypes are defined locally */
void ConfigureOperatingFrequency(void);
void EnablePeripheralModules(void);
void ConfigurePortPins(void);

/***********************************************************************************
User Program Code
***********************************************************************************/

/***********************************************************************************
Function Name:  HardwareSetup
Description:    Sets up hardware
Parameters:     none
Return value:   none
***********************************************************************************/

void HardwareSetup(void)
{
	ConfigureOperatingFrequency();

	ConfigurePortPins();

	EnablePeripheralModules();

	/* ConfigureInterrupts(); */
}

/***********************************************************************************
End of function HardwareSetup
***********************************************************************************/

/***********************************************************************************
Function Name:  ConfigureOperatingFrequency
Description:    Sets up operating speed
Parameters:     none
Return value:   none
***********************************************************************************/
void ConfigureOperatingFrequency(void)
{
	unsigned int i;

	/* set protection register to allow writing to clock control registers*/
	prc0 =1;
	/* port P4_6, P4_7 are XIN-XOUT pins */
	cm13 = 1;
	/* XIN-XOUT drive capacity select HIGH */
	cm15 = 1;
	/* Xin clock oscillates */
	cm05 = 0;
	/* This setting is an example of waiting time for the oscillation stabilization.
		Please evaluate the time for oscillation stabilization by a user. */
	for (i=0; i<= 0x100;i++);  
	/* system clock selects XIN clock */
	ocd2 = 0;
	/* set divide for BLCK to no division mode */
	cm16 = 0;
	cm17 = 0;
	/* system clock division select (CM16, CM17 enabled) */
	cm06 = 0;
	/*protect clock control registers*/
	prc0=0;

}
/***********************************************************************************
End of function ConfigureOperatingFrequency
***********************************************************************************/

/***********************************************************************************
Function Name:  EnablePeripheralModules
Description:    Enables Peripheral Modules before use also enables data flash
Parameters:     none
Return value:   none
***********************************************************************************/
void EnablePeripheralModules(void)
{
	/* All modules are active in the R8C device */

}
/***********************************************************************************
End of function EnablePeripheralModules
***********************************************************************************/

/***********************************************************************************
Function Name:  ConfigurePortPins
Description:    Configures port pins
Parameters: none
Return value: none
***********************************************************************************/
void ConfigurePortPins(void)
{
/* Port pins default to inputs. To ensure safe initialisation set the pin states
before changing the data direction registers. This will avoid any unintentional
state changes on the external ports.
Many peripheral modules will override the setting of the port registers. Ensure
that the state is safe for external devices if the internal peripheral module is
disabled or powered down. */


/* Switch Port configuration */
	/* All pins are inputs by default */

/* LED Port configuration */
///	p0 = 0xff;
	/* disenable PD0 protect bit */
	prc2 = 1;
	pd0 = 0xfc;

/* SW Port configuration */
	pd1_7 = 0;
	pd3_3 = 0;
	pd1_0 = 0;
	pur0 = 0x04;

/* LCD Module Port configuration */
	/* Set control = outputs */
///	pd5 = 0x18;

	/* disenable PD0 protect bit */
///	prc2 = 1;
	/* Set data = outputs */
///	pd0 |= 0xf0;

}
/***********************************************************************************
End of function ConfigurePortPins
***********************************************************************************/


