

#ifndef RSKR8C27DEF_H
#define RSKR8C27DEF_H

/* Peripheral Clock Speed set up in ConfigureOperatingFrequency() */
#define	f1_CLK_SPEED		20000000
#define XIN_FREQ 			f1_CLK_SPEED

/* Switches */
#define	SW1 			p1_7
#define SW2 			p3_3
#define SW3 			p1_0
#define SW1_DDR			pd1_7
#define SW2_DDR			pd3_3
#define SW3_DDR			pd1_0

/* LEDs */
#define	LED0			p0_0
#define	LED1			p0_1
#define	LED2			p0_2
#define	LED3			p0_3

#define	LED0_DDR		pd0_0
#define	LED1_DDR		pd0_1
#define	LED2_DDR		pd0_2
#define	LED3_DDR		pd0_3

/* LED port settings */
#define LED_PORT_DR		p0		/* LED Port data register */
#define LED_BIT			(0x0F)			/* Port bit to toggle for flashing LED */

#define LED_ON			0
#define LED_OFF			1
#define LEDS_ON			(0x00)
#define LEDS_OFF		(0x0F)
#define SET_BIT_HIGH	(1)
#define SET_BIT_LOW		(0)
#define SET_BYTE_HIGH	(0xFF)
#define SET_BYTE_LOW	(0x00)

/* Common Defines */
#ifndef TRUE
#define TRUE			1
#endif
#ifndef FALSE
#define FALSE			0
#endif

#define ENABLE_IRQ		{_asm(" FSET I");}
#define DISABLE_IRQ		{_asm(" FCLR I");}


#endif /* RSKR8C27DEF_H_INCLUDED */
