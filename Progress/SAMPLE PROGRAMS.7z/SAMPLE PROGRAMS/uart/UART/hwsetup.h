


#ifndef HWSETUP_H
#define HWSETUP_H

/***********************************************************************************
Function Prototypes
***********************************************************************************/

void HardwareSetup( void );

#endif /* HWSETUP_H_INCLUDED */