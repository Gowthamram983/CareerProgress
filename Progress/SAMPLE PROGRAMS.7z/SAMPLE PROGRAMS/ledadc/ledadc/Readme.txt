-------- PROJECT GENERATOR --------
PROJECT NAME :	ledadc
PROJECT DIRECTORY :	C:\WorkSpace\ledadc\ledadc
CPU SERIES :	R8C/Tiny
CPU GROUP :	27
TOOLCHAIN NAME :	Renesas M16C Standard Toolchain
TOOLCHAIN VERSION :	5.45.00
GENERATION FILES :
    C:\WorkSpace\ledadc\ledadc\ledadc.c
        main program file.
    C:\WorkSpace\ledadc\ledadc\nc_define.inc
        interrupt program.
START UP FILES :
    C:\WorkSpace\ledadc\ledadc\sfr_r827.h
    C:\WorkSpace\ledadc\ledadc\sfr_r827.inc
    C:\WorkSpace\ledadc\ledadc\sect30.inc
    C:\WorkSpace\ledadc\ledadc\ncrt0.a30

DATE & TIME : 7/13/2011 12:44:20 PM
