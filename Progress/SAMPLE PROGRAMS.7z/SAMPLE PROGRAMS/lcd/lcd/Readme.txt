-------- PROJECT GENERATOR --------
PROJECT NAME :	lcd
PROJECT DIRECTORY :	C:\WorkSpace\lcd\lcd
CPU SERIES :	R8C/Tiny
CPU GROUP :	27
TOOLCHAIN NAME :	Renesas M16C Standard Toolchain
TOOLCHAIN VERSION :	5.45.00
GENERATION FILES :
    C:\WorkSpace\lcd\lcd\lcd.c
        main program file.
    C:\WorkSpace\lcd\lcd\nc_define.inc
        interrupt program.
START UP FILES :
    C:\WorkSpace\lcd\lcd\sfr_r827.h
    C:\WorkSpace\lcd\lcd\sfr_r827.inc
    C:\WorkSpace\lcd\lcd\ncrt0.a30
    C:\WorkSpace\lcd\lcd\sect30.inc

DATE & TIME : 08.07.2011 05:58:57
