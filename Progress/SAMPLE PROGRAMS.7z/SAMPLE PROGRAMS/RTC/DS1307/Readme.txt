-------- PROJECT GENERATOR --------
PROJECT NAME :	DS1307
PROJECT DIRECTORY :	I:\Current Workings\R8C27\DS1307\DS1307
CPU SERIES :	R8C/Tiny
CPU GROUP :	27
TOOLCHAIN NAME :	Renesas M16C Standard Toolchain
TOOLCHAIN VERSION :	5.45.00
GENERATION FILES :
    I:\Current Workings\R8C27\DS1307\DS1307\DS1307.c
        main program file.
    I:\Current Workings\R8C27\DS1307\DS1307\nc_define.inc
        interrupt program.
START UP FILES :
    I:\Current Workings\R8C27\DS1307\DS1307\sfr_r827.h
    I:\Current Workings\R8C27\DS1307\DS1307\sfr_r827.inc
    I:\Current Workings\R8C27\DS1307\DS1307\ncrt0.a30
    I:\Current Workings\R8C27\DS1307\DS1307\sect30.inc

DATE & TIME : 10/3/2010 12:46:57 PM
