-------- PROJECT GENERATOR --------
PROJECT NAME :	new
PROJECT DIRECTORY :	C:\WorkSpace\new\new
CPU SERIES :	R8C/Tiny
CPU GROUP :	27
TOOLCHAIN NAME :	Renesas M16C Standard Toolchain
TOOLCHAIN VERSION :	5.45.00
GENERATION FILES :
    C:\WorkSpace\new\new\new.c
        main program file.
    C:\WorkSpace\new\new\nc_define.inc
        interrupt program.
START UP FILES :
    C:\WorkSpace\new\new\sfr_r827.h
    C:\WorkSpace\new\new\sfr_r827.inc
    C:\WorkSpace\new\new\sect30.inc
    C:\WorkSpace\new\new\ncrt0.a30

SELECT TARGET :
    M16C R8C Simulator
DATE & TIME : 6/18/2011 10:20:01 AM
