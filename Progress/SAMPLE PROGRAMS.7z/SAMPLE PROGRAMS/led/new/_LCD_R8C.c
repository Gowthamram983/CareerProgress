//*************************************************************************************************//
//*************************************************************************************************//
//-------------------------------------------- 16X2 LCD -------------------------------------------//
//*************************************************************************************************//
//*************************************************************************************************//


//-------------------------------------------------------------------------------------------------//
//-------------------------------- Variables & Functions Declaration ------------------------------//
//-------------------------------------------------------------------------------------------------//

#define lcd_port p0     							// Dataport of LCD-Display (D4..D7) 
#define	rs	p0_2
#define	en	p0_3

void lcd_delay();
void lcd_init(void);                        		// Initialize the LCD display
void lcd_cginit(void);                        		// Initialize the Custom Graphics in LCD display
void lcd_clear(void);								// Clear LCD
void lcd_command(char cmd);		    				// Send LCD Command
void lcd_gotoxy(char x,char y);						// Goto X,Y position in the LCD display
void lcd_putchar(char value);  						// Writes a character to display
void lcd_printxy(char x,char y,char *text);
void lcd_print_b(char val_a);


//-------------------------------------------------------------------------------------------------//
//----------------------------------------- Delay Routine -----------------------------------------//
//-------------------------------------------------------------------------------------------------//

void lcd_delay()
{
	unsigned char a;
	a=255;
	while(a--);
	a=255;
	while(a--);
}

//-------------------------------------------------------------------------------------------------//
//-------------------------------------- LCD Initialisation ---------------------------------------//
//-------------------------------------------------------------------------------------------------//

void lcd_init(void)
{
    rs=0;
	en=1;
	lcd_port=0x20;
	en=0;
	lcd_delay();
	lcd_command(0x28);
	lcd_command(0x06);
	lcd_command(0x0C);								// OC - Cursor Off ~ OE - Cursor ON ~ 0F - Cursor Blink
	lcd_command(0x01);								// Clears the display
	lcd_command(0x80);
}

//-------------------------------------------------------------------------------------------------//
//------------------------------------------- LCD Clear -------------------------------------------//
//-------------------------------------------------------------------------------------------------//

void lcd_clear(void)
{
	lcd_command(0x01);
	lcd_delay();
	lcd_delay();
	lcd_delay();
}

//-------------------------------------------------------------------------------------------------//
//--------------------------------------- LCD Send Command ----------------------------------------//
//-------------------------------------------------------------------------------------------------//

void lcd_command(unsigned char cmd)
{
   	rs=0;							// Switch to command register
//	lcd_port = (lcd_port&0x0F)|((cmd<<4)&0xF0);
	lcd_port = (lcd_port&0x0F)|(cmd&0xF0);			// Set LCD_DATA to high nibble of value
	en = 1;
	en = 0;           								// Write data to display
//	lcd_port = (lcd_port&0x0F)|(cmd&0xF0);													
	lcd_port = (lcd_port&0x0F)|((cmd<<4)&0xF0);		// Set LCD_DATA to lower nibble of value
	en = 1;
	en = 0;           								// Write data to display
	lcd_delay();                       				// Wait 400�s
}

//-------------------------------------------------------------------------------------------------//
//----------------------------------------- LCD Goto X,Y ------------------------------------------//
//-------------------------------------------------------------------------------------------------//

void lcd_gotoxy(unsigned char x,unsigned char y)
{
   	//if((x<1||x>2)) 								// if((x<1||x>2)&&(y<1||y>16))
	if(x>2)
	{
		x=1; 										// x=1; y=1;
	}
	if(x == 1)
		lcd_command(0x7F+y);
	else
		lcd_command(0xBF+y);
}

//-------------------------------------------------------------------------------------------------//
//---------------------------------------- LCD Print Text -----------------------------------------//
//-------------------------------------------------------------------------------------------------//


void lcd_putchar(unsigned char value)
{
	rs = 1;              						    // Switch to data register					 	
	lcd_port = (lcd_port&0x0F)|(value&0xF0);		// Set LCD_DATA to high nibble of value
	en = 1;
	en = 0;           								// Write data to display												
	lcd_port = (lcd_port&0x0F)|((value<<4)&0xF0);	// Set LCD_DATA to lower nibble of value
	en = 1;
	en = 0;           								// Write data to display
	lcd_delay();  
	//lcd_delay();                     				// Wait 400�s
} 

//-------------------------------------------------------------------------------------------------//

void lcd_printxy(unsigned char x,unsigned char y, unsigned char *text)
{
	lcd_gotoxy(x,y);            						// Set cursor position
	while(*text)          								// while not end of text
	{
	  lcd_putchar(*text); 							    // Write character and increment position
	  text++;
	} 
}

//-------------------------------------------------------------------------------------------------//
//------------------------------- Writing 8-bit Value to LCD --------------------------------------//
//-------------------------------------------------------------------------------------------------//

void lcd_print_b(unsigned char val_a)
{
	unsigned char temp_a;
							   						// 123
	temp_a = val_a/100;				 				// 123 / 100 = 1
	if(temp_a!=0)
	{
		lcd_putchar(temp_a+0x30);
	}
	temp_a = val_a/10;	   							// 123 / 10 = 12
	temp_a = temp_a%10;								// 12 % 10 = 2
	lcd_putchar(temp_a+0x30);
	temp_a = val_a%10;								// 123 % 10 = 3
	lcd_putchar(temp_a+0x30);
}

