#ifndef _UPDATE_LOCK_CRITICAL_DATA_C_
#define _UPDATE_LOCK_CRITICAL_DATA_C_

#include "Update_Lock_Critical_Data.h"

void Update_Lock_Critical_Data()
{
/*C Code for 2.11.8.4.1 Update_Lock_Critical_Data() function*/
// #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.4.1 Update_Lock_Critical_Data() function' for the implementation specification to replace this stub"
}


#endif/*_UPDATE_LOCK_CRITICAL_DATA_C_ */

