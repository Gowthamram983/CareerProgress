#ifndef _Extract_Char15_FromVIN_C_
#define _Extract_Char15_FromVIN_C_

#include "Extract_Char15_FromVIN.h"

unsigned char Extract_Char15_FromVIN()
{
    /*C Code for Section 2.4.67.2 Generating Hash Algorithm and VIN Selection and R: 2.4.67.2.1  Extract_Char15_FromVIN() function*/

// #warning "Code Stubbed for Testing: refer to 'Section 2.4.67.2 and R: 2.4.67.2.1' for the implementation specification to replace this stub"
    /* Below code is stubbed for unit testing.  Supplier shall update the logic for extraction of 15th character from VIN.*/
    unsigned char vin15_loc = 0;

return vin15_loc;
}


#endif/*_Extract_Char15_FromVIN_C_ */
