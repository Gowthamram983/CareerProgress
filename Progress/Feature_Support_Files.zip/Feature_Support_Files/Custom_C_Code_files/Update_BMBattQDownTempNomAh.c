#ifndef _UPDATE_BMBATTQDOWNTEMPNOMAH_C_
#define _UPDATE_BMBATTQDOWNTEMPNOMAH_C_

#include "Update_BMBattQDownTempNomAh.h"

void Update_BMBattQDownTempNomAh()
{
/*C Code for 2.11.8.6.3 Update_BMBattQDownTempNomAh() function*/
    
//   #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.6.3 Update_BMBattQDownTempNomAh() function' for the implementation specification to replace this stub"  
    
}


#endif/*_UPDATE_BMBATTQDOWNTEMPNOMAH_C_ */

