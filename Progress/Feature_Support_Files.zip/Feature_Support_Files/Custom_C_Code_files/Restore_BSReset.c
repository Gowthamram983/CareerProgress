#ifndef _RESTORE_BSRESET_C_
#define _RESTORE_BSRESET_C_

#include "Restore_BSReset.h"

void Restore_BSReset()
{
/*C Code for 2.11.8.6.8 Restore_BSReset() function*/
//     #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.6.8 Restore_BSReset()' for the implementation specification to replace this stub"
}


#endif/*_RESTORE_BSRESET_C_ */

