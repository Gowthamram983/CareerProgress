#ifndef _BCM_SQRT_H_
#define _BCM_SQRT_H_

typedef unsigned char UInt8; /* 8 bit unsigned integer basetype */
typedef unsigned short int UInt16; /* 16 bit unsigned integer basetype */
typedef unsigned long int UInt32; /* 32 bit unsigned integer basetype */

UInt16 BCM_Sqrt(UInt32);

#endif/*_BCM_SQRT_H_ */
