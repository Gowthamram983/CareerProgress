#ifndef _SCL_RNDCHECK_H_
#define _SCL_RNDCHECK_H_


int SCL_RNDCheck(int* SCLRndNo,int RandCS);


#endif/*_SCL_RNDCHECK_H_ */

