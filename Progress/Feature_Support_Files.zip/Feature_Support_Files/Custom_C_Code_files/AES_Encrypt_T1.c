#ifndef _AES_ENCRYPT_T1_C_
#define _AES_ENCRYPT_T1_C_

#include "AES_Encrypt.h"

void AES_Encrypt_T1(UInt8 *AESWorkingTextT1, UInt8 *AESKeyT1)
{
    UInt8 i;
    for(i=0; i<16; i++)
    {
        *AESWorkingTextT1 = (*AESWorkingTextT1++) + (*AESKeyT1++);
        
    }
}


#endif/*_AES_ENCRYPT_T1_C_ */

