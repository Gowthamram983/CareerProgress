#ifndef _UPDATE_IGNPREOFFACTV_B_STATUS_C_
#define _UPDATE_IGNPREOFFACTV_B_STATUS_C_

#include "Update_IgnPreOffActv_B_Status.h"

void Update_IgnPreOffActv_B_Status()
{

/*C Code for R:2.11.8.23.1.1 Update_IgnPreOffActv_B_Status() function*/ 
// #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.23.1 Update_IgnPreOffActv_B_Status() function' for the implementation specification to replace this stub"
    
}

#endif/*_UPDATE_IGNPREOFFACTV_B_STATUS_C_ */