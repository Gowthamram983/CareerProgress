#ifndef _RESTORE_BMBATTQDOWNTEMPNOMAH_C_
#define _RESTORE_BMBATTQDOWNTEMPNOMAH_C_

#include "Restore_BMBattQDownTempNomAh.h"

void Restore_BMBattQDownTempNomAh()
{
/*C Code for 2.11.8.6.4 Restore_BMBattQDownTempNomAh() function*/

// #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.6.4 Restore_BMBattQDownTempNomAh() function' for the implementation specification to replace this stub"

}


#endif/*_RESTORE_BMBATTQDOWNTEMPNOMAH_C_ */

