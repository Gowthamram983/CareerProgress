#ifndef _AES_ENCRYPT_LBI_C_
#define _AES_ENCRYPT_LBI_C_

#include "AES_Encrypt.h"

void AES_Encrypt_LBI(UInt8 *AESWorkingTextLBI, UInt8 *AESKeyLBI)
{
    UInt8 i;
    for(i=0; i<16; i++)
    {
        *AESWorkingTextLBI = (*AESWorkingTextLBI++) + (*AESKeyLBI++);
        
    }
}


#endif/*_AES_ENCRYPT_LBI_C_ */

