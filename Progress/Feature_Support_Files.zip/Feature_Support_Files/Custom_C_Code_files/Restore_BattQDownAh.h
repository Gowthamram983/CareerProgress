#ifndef _RESTORE_BATTQDOWNAH_H_
#define _RESTORE_BATTQDOWNAH_H_


void Restore_BattQDownAh();


#endif/*_RESTORE_BATTQDOWNAH_H_ */

