#ifndef _PARITYCHECK_C_
#define _PARITYCHECK_C_

#include "ParityCheck.h"

unsigned int ParityCheck(unsigned int SCL_SeqNum, unsigned int SCL_Parity) {
/*    unsigned int count = 0;
    while(SCL_SeqNum >= 1) {
        if ( SCL_SeqNum % 2 != 0 ) {
            count++;
        }        
        SCL_SeqNum = (unsigned int)(SCL_SeqNum / 2);
    }
    if(SCL_Parity == 1) {       
        count++;}
    if ( count % 2 == 1){ 
        return  1;}
    else {
        return 0;} */
    
    /*SCL_Parity will be treated here as Parity Fault Flag*/
    if (SCL_Parity==0)
    {return 1;} // TRUE -> Parity Check Passed
    else
    {return 0;}
//if(SCL_SeqNum = 1)        count++;
/*C Code for ParityCheck() function*/
}

#endif/*_PARITYCHECK_C_ */


