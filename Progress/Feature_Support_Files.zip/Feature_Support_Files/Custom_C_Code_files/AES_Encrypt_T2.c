#ifndef _AES_ENCRYPT_T2_C_
#define _AES_ENCRYPT_T2_C_

#include "AES_Encrypt.h"

void AES_Encrypt_T2(UInt8 *AESWorkingTextT2, UInt8 *AESKeyT2)
{
    UInt8 i;
    for(i=0; i<16; i++)
    {
        *AESWorkingTextT2 = (*AESWorkingTextT2++) + (*AESKeyT2++);
        
    }
}


#endif/*_AES_ENCRYPT_T2_C_ */

