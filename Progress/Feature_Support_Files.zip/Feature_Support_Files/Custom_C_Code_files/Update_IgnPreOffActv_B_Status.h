#ifndef _UPDATE_IGNPREOFFACTV_B_STATUS_H_
#define _UPDATE_IGNPREOFFACTV_B_STATUS_H_

void Update_IgnPreOffActv_B_Status();


#endif/*_Update_IgnPreOffActv_B_Status_H_ */
