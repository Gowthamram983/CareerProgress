#ifndef _AES_ENCRYPT_PAAK_C_
#define _AES_ENCRYPT_PAAK_C_

#include "AES_Encrypt.h"

void AES_Encrypt_Paak(UInt8 *AESWorkingTextPaak, UInt8 *AESKeyPaak)
{
    UInt8 i;
    for(i=0; i<16; i++)
    {
        *AESWorkingTextPaak = (*AESWorkingTextPaak++) + (*AESKeyPaak++);
        
    }
}


#endif/*_AES_ENCRYPT_PAAK_C_ */

