#ifndef _Get_DID_DE5C_Data_C_
#define _Get_DID_DE5C_Data_C_

#include "Get_DID_DE5C_Data.h"

unsigned short Get_DID_DE5C_Data()
{
    /*C Code for Section 2.4.42.3 and R: 2.4.42.3.2 and R: 2.4.42.3.3 Get_DID_DE5C_Data() function*/

// #warning "Code Stubbed for Testing: refer to 'Section 2.4.42.3 and R: 2.4.42.3.2 and R: 2.4.42.3.3 Get_DID_DE5C_Data() function' for the implementation specification to replace this stub" 
}


#endif/*_Get_DID_DE5C_Data_C_ */
