#ifndef _RESTORE_BSRESET_H_
#define _RESTORE_BSRESET_H_

// #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.6.8 Restore_BSReset()' for the implementation specification to replace this stub"
void Restore_BSReset();


#endif/*_RESTORE_BSRESET_H_ */

