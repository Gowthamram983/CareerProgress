#ifndef _PAAK_RANDOM_FIVE_BYTE_C_
#define _PAAK_RANDOM_FIVE_BYTE_C_

#include "Paak_Random_Five_Byte.h"

void Paak_Random_Five_Byte(unsigned char* Random_Data)
{
/*C Code for **** Paak_Random_Five_Byte() function*/
/*R: 2.17.3.2.82*/

// #warning "Code Stubbed for Testing: refer to 'Section:2.17.3.2  Paak_Random_Five_Byte() function' for the implementation specification to replace this stub"
    
 static unsigned char Value=0;
/*For the Unit model testing Random_Data is assigned with the constant number from 1 to 5.
 Supplier shall inplement the random number generator to generate the 5 byte random number for Random_Data.
     
Random_Data[0] = Random(0-255);
Random_Data[1] = Random(0-255);
Random_Data[2] = Random(0-255);
Random_Data[3] = Random(0-255);
Random_Data[4] = Random(0-255);
*/
    
Random_Data[0] = Value;
Random_Data[1] = Value;
Random_Data[2] = Value;
Random_Data[3] = Value;
Random_Data[4] = Value;

if(Value<255)
{
Value=Value+1;
}
else 
{
Value=0;    
}
        
}


#endif/*_PAAK_RANDOM_FIVE_BYTE_C_ */

