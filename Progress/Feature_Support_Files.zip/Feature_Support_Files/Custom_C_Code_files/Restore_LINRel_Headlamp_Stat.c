#ifndef _RESTORE_LINREL_HEADLAMP_STAT_C_
#define _RESTORE_LINREL_HEADLAMP_STAT_C_

#include "Restore_LINRel_Headlamp_Stat.h"

void Restore_LINRel_Headlamp_Stat()
{
    /*C Code for Restore_LINRel_Headlamp_Stat() function*/
//     #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.12.2 Restore_LINRel_Headlamp_Stat() function' for the implementation specification to replace this stub"
}


#endif/*_RESTORE_LINREL_HEADLAMP_STAT_C_ */

