#ifndef _PAAK_RANDOM_FIVE_BYTE_H_
#define _PAAK_RANDOM_FIVE_BYTE_H_

// #warning "Code Stubbed for Testing: refer to 'Section:2.17.3.2  Paak_Random_Five_Byte() function' for the implementation specification to replace this stub"

void Paak_Random_Five_Byte(unsigned char* Random_Data);


#endif/*_PAAK_RANDOM_FIVE_BYTE_H_ */

