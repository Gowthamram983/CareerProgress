#ifndef _Extract_Char16_FromVIN_C_
#define _Extract_Char16_FromVIN_C_

#include "Extract_Char16_FromVIN.h"

unsigned char Extract_Char16_FromVIN()
{
    /*C Code for Section 2.4.67.2 Generating Hash Algorithm and VIN Selection and R: 2.4.67.2.2  Extract_Char16_FromVIN() function*/

// #warning "Code Stubbed for Testing: refer to 'Section 2.4.67.2 and R: 2.4.67.2.2' for the implementation specification to replace this stub"
    /* Below code is stubbed for unit testing.  Supplier shall update the logic for extraction of 16th character from VIN.*/
    unsigned char vin16_loc = 0;

return vin16_loc;
}


#endif/*_Extract_Char16_FromVIN_C_ */
