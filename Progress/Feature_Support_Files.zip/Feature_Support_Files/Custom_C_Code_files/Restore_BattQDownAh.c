#ifndef _RESTORE_BATTQDOWNAH_C_
#define _RESTORE_BATTQDOWNAH_C_

#include "Restore_BattQDownAh.h"

void Restore_BattQDownAh()
{
/*C Code for 2.11.8.6.10 Restore_BattQDownAh() function*/
}


#endif/*_RESTORE_BATTQDOWNAH_C_ */

