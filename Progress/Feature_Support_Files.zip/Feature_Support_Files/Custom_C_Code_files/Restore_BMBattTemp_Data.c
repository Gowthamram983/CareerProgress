#ifndef _RESTORE_BMBATTTEMP_DATA_C_
#define _RESTORE_BMBATTTEMP_DATA_C_

#include "Restore_BMBattTemp_Data.h"

void Restore_BMBattTemp_Data()
{
/*C Code for 2.11.8.6.2 Restore_BMBattTemp_Data() function*/

// #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.6.2 Restore_BMBattTemp_Data() function' for the implementation specification to replace this stub"

}


#endif/*_RESTORE_BMBATTTEMP_DATA_C_ */

