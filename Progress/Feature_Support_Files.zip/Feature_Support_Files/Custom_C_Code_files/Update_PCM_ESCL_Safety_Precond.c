#ifndef _UPDATE_PCM_ESCL_SAFETY_PRECOND_C_
#define _UPDATE_PCM_ESCL_SAFETY_PRECOND_C_

#include "Update_PCM_ESCL_Safety_Precond.h"

void Update_PCM_ESCL_Safety_Precond()
{
/*C Code for Update_PCM_ESCL_Safety_Precond() function*/
//     #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.9.1 Update_PCM_ESCL_Safety_Precond() function' for the implementation specification to replace this stub"
}

#endif/*_UPDATE_PCM_ESCL_SAFETY_PRECOND_C_ */

