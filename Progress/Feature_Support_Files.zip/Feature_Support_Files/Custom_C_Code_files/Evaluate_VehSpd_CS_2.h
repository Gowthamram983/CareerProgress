#ifndef _EVALUATE_VEHSPD_CS_2_H_
#define _EVALUATE_VEHSPD_CS_2_H_


int Evaluate_VehSpd_CS_2(unsigned short ABS_VehSpeed,unsigned char ABS_VehSpeed_QF,unsigned char ABS_VehSpeed_Cnt, unsigned char ABS_VehSpeed_CS);


#endif/*_EVALUATE_VEHSPD_CS_2_H_ */

