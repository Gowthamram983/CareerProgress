#ifndef _RESTORE_BMBATTTEMP_DATA_H_
#define _RESTORE_BMBATTTEMP_DATA_H_

// #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.6.2 Restore_BMBattTemp_Data() function' for the implementation specification to replace this stub"

void Restore_BMBattTemp_Data();


#endif/*_RESTORE_BMBATTTEMP_DATA_H_ */

