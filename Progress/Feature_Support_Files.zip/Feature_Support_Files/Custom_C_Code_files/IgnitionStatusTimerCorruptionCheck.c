#ifndef _IGNITIONSTATUSTIMERCORRUPTIONCHECK_C_
#define _IGNITIONSTATUSTIMERCORRUPTIONCHECK_C_

#include "IgnitionStatusTimerCorruptionCheck.h"

unsigned char IgnitionStatusTimerCorruptionCheck()
{

/*Dummy C Code for  R: 2.13.6.1.53k IgnitionStatusTimerCorruptionCheck() function*/ 
/*Supplier must implement this function to detect Ignition Status delay timer*/
       
     unsigned char TimerCheck_Temp = 0;
    
    if (TimerCheck_Temp==1)
        return 1;
    else
        return 0;

}

#endif/*_IGNITIONSTATUSTIMERCORRUPTIONCHECK_C_ */