#ifndef _UPDATE_BATTQDOWNAH_H_
#define _UPDATE_BATTQDOWNAH_H_


void Update_BattQDownAh();


#endif/*_UPDATE_BATTQDOWNAH_H_ */

