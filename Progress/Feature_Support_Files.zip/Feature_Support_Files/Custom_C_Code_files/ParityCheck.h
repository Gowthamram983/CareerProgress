#ifndef _PARITYCHECK_H_
#define _PARITYCHECK_H_


unsigned int ParityCheck(unsigned int SCL_SeqNum, unsigned int SCL_Parity);


#endif/*_PARITYCHECK_H_ */

