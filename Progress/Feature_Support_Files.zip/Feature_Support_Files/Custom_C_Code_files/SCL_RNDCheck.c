#ifndef _SCL_RNDCHECK_C_
#define _SCL_RNDCHECK_C_

#include "SCL_RNDCheck.h"
// Dummy Logic for Checksum
int SCL_RNDCheck(int* SCLRndNo,int RandCS)
{    
    int temp1 = 0;    
  //  temp1 = SCLRndNo[0]+SCLRndNo[1]+SCLRndNo[2]+SCLRndNo[3]+SCLRndNo[4];    
temp1=RandCS;
 //   if( temp1 == RandCS )
 if( temp1 == 2)
        return  1;
    else
        return  0; 
}

#endif/*_SCL_RNDCHECK_C_ */