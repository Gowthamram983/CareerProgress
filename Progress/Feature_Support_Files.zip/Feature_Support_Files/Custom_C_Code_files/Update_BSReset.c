#ifndef _UPDATE_BSRESET_C_
#define _UPDATE_BSRESET_C_

#include "Update_BSReset.h"

void Update_BSReset()
{
/*C Code for 2.11.8.6.7 Update_BSReset() function*/
//     #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.6.7 Update_BSReset() function' for the implementation specification to replace this stub"
}


#endif/*_UPDATE_BSRESET_C_ */

