#ifndef _UPDATE_CHILDLOCK_FLAG_CRITICAL_DATA_H_
#define _UPDATE_CHILDLOCK_FLAG_CRITICAL_DATA_H_

// #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.4.2 Update_ChildLock_Flag_Critical_Data() function' for the implementation specification to replace this stub"

void Update_ChildLock_Flag_Critical_Data();


#endif/*_UPDATE_CHILDLOCK_FLAG_CRITICAL_DATA_H_ */
