#ifndef _EVALUATE_VEHSPD_CS_C_
#define _EVALUATE_VEHSPD_CS_C_

#include "Evaluate_VehSpd_CS.h"

int  Evaluate_VehSpd_CS(unsigned short ABS_VehSpeed,unsigned char ABS_VehSpeed_QF,unsigned char ABS_VehSpeed_Cnt, unsigned char ABS_VehSpeed_CS) {
/*Dummy C Code for Checksum evaluation*/
    
    unsigned char ABS_CS_Rslt_Temp=0;
    
    ABS_CS_Rslt_Temp=(unsigned char)(ABS_VehSpeed & 0xFF);
    ABS_CS_Rslt_Temp=(unsigned char)(ABS_CS_Rslt_Temp+(unsigned int)((ABS_VehSpeed>>8) & 0xFF));
    ABS_CS_Rslt_Temp=(unsigned char)(ABS_CS_Rslt_Temp+ABS_VehSpeed_QF);
    ABS_CS_Rslt_Temp=(unsigned char)(ABS_CS_Rslt_Temp+ABS_VehSpeed_Cnt);
    ABS_CS_Rslt_Temp=(unsigned char)(ABS_CS_Rslt_Temp+ABS_VehSpeed_CS+1);
    
    
    if (ABS_CS_Rslt_Temp==0)
        return 1;
    else
        return 0;
}

#endif/*_EVALUATE_VEHSPD_CS_C_ */


