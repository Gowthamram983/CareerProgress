#ifndef _UPDATE_BATTQDOWNAH_C_
#define _UPDATE_BATTQDOWNAH_C_

#include "Update_BattQDownAh.h"

void Update_BattQDownAh()
{
/*C Code for 2.11.8.6.9 Update_BattQDownAh() function*/
}


#endif/*_UPDATE_BATTQDOWNAH_C_ */

