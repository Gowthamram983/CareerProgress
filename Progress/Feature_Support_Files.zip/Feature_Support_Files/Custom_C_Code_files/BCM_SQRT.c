#ifndef _BCM_SQRT_C_
#define _BCM_SQRT_C_

#include "BCM_SQRT.h"

/* Code taken from Wikipedia */
UInt16 BCM_Sqrt(UInt32 Elapsed_Time_TValue)
{
    UInt32 rem =  0;
    UInt32 root=0;
    UInt8 looper=0;
    for (looper=0;looper<16;looper++)
    {
        root = root << 1;
        rem = ((rem << 2) + (Elapsed_Time_TValue >> 30));
        Elapsed_Time_TValue  = Elapsed_Time_TValue << 2;
        root++;
        if(root <= rem)
        {
            rem = rem - root;
            root++;
        }
        else
            root--;
    }
    return (root >> 1);
}

#endif/*_BCM_SQRT_C_ */
