#ifndef _UPDATE_RUN_ACTIVE_COUNT_C_ 
#define _UPDATE_RUN_ACTIVE_COUNT_C_ 

#include "Update_Run_Active_Count.h"

void Update_Run_Active_Count()
{
/*C Code for 2.11.8.11.1 Update_Run_Active_Count() function*/

//   #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.11.1 Update_Run_Active_Count() function' for the implementation specification to replace this stub"

}


#endif/*_UPDATE_RUN_ACTIVE_COUNT_C_ */