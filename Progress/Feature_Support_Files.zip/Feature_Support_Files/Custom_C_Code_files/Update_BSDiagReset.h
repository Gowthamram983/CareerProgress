#ifndef _UPDATE_BSDIAGRESET_H_
#define _UPDATE_BSDIAGRESET_H_

// #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.6.5 Update_BSDiagReset() function' for the implementation specification to replace this stub"
void Update_BSDiagReset();


#endif/*_UPDATE_BSDIAGRESET_H */

