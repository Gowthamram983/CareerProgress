#ifndef _AES_ENCRYPT_H_
#define _AES_ENCRYPT_H_
typedef unsigned char UInt8;

void AES_Encrypt_T1(UInt8 *AESWorkingTextT1, UInt8 *AESKeyT1);
void AES_Encrypt_T2(UInt8 *AESWorkingTextT2, UInt8 *AESKeyT2);
void AES_Encrypt_Paak(UInt8 *AESWorkingTextPaak, UInt8 *AESKeyPaak);
void AES_Encrypt_LBI(UInt8 *AESWorkingTextLBI, UInt8 *AESKeyLBI);


#endif/*_AES_ENCRYPT_H_ */

