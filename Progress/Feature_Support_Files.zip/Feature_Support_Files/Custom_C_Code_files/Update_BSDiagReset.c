#ifndef _UPDATE_BSDIAGRESET_C_
#define _UPDATE_BSDIAGRESET_C_

#include "Update_BSDiagReset.h"

void Update_BSDiagReset()
{
/*C Code for 2.11.8.6.5 Update_BSDiagReset() function*/
//     #warning "Code Stubbed for Testing: refer to 'Section: 2.11.8.6.5 Update_BSDiagReset() function' for the implementation specification to replace this stub"
}


#endif/*_UPDATE_BSDIAGRESET_C_ */

