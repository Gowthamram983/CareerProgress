#ifndef _UPDATE_SECUREIDLEMODE_C_ 
#define _UPDATE_SECUREIDLEMODE_C_ 

#include "Update_SecureIdleMode.h"

void Update_SecureIdleMode()
{
/*C Code for 2.13.11.3.20 Update_SecureIdleMode() function*/
//     #warning "Code Stubbed for Testing: refer to 'Section: 2.13.11.3.20 Update_SecureIdleMode() function' for the implementation specification to replace this stub"
}


#endif/*_UPDATE_SECUREIDLEMODE_C_ */